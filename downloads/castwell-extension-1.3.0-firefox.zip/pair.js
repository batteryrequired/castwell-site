// Castwell Toolkit for TikTok & Facebook LIVE - on Castwell Toolkit's own dashboard (on this PC only): picks up the connect code by itself, so
// nobody has to copy it. Castwell Toolkit's page asks with window.postMessage({castwellPair: {code}}); this answers with
// {castwellExt: {version, paired}} so the dashboard can show that the extension is there.
(() => {
  if (!document.querySelector('meta[name="castwell"]')) return;          // not Castwell Toolkit's page
  async function hello() {
    const { code = "", address = "" } = await chrome.storage.local.get(["code", "address"]);
    window.postMessage({ castwellExt: { version: chrome.runtime.getManifest().version, paired: !!code && address === location.origin,
                                        code_set: !!code } }, location.origin);
  }
  window.addEventListener("message", async e => {
    if (e.source !== window || e.origin !== location.origin || !e.data) return;
    const p = e.data.castwellPair;
    if (p && typeof p.code === "string" && /^[0-9A-F]{4}(-[0-9A-F]{4}){2}$/i.test(p.code)) {
      await chrome.storage.local.set({ code: p.code.toUpperCase(), address: location.origin });
      hello();
    } else if (e.data.castwellPing) {
      hello();
    }
  });
  hello();
})();
