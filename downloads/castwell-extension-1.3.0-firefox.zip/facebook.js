// Castwell Toolkit for TikTok & Facebook LIVE - runs on facebook.com. On a Facebook live video page (Live Producer,
// facebook.com/.../videos/..., watch/live, ?v=) it reads new comments, Stars, follows and shares plus the viewer count,
// sends them to Castwell Toolkit every 1.5 s (through background.js), and types the replies Castwell Toolkit sends back
// into the comment box - as the Facebook account (or Page) signed in in this browser.
// Facebook changes its page often and names nothing in a stable way, so this goes by what a screen reader sees:
// every comment is an [role="article"], the commenter's name is its first link, the words are the text after it.
(() => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const txt = el => ((el && (el.innerText || el.textContent)) || "").replace(/\s+/g, " ").trim();
  const UI = /^(Like|Reply|React|Share|Follow|Edit|Hide|Author|Top fan|Highlighted|See translation|Send message|Pin|Unpin|Pinned comment|Follow back|Following|See thread|Write a reply.*|·|\d+\s*[smhdw]|\d+\s+(seconds?|minutes?|hours?|days?|weeks?)( ago)?|Just now|Edited)$/i;
  // Live Producer (tested live 2026-11-25): the name links have no role="link"; every comment's own label names the
  // commenter - "Comment by Jason Thompson about a minute ago"
  const BY = /^(?:Comment|Reply) by (.+?) (?:about |less than |an? |\d+ |just now|yesterday|on )/i;

  const onLivePage = () => /\/live\/producer\/|\/videos\/|\/watch\/live\/|[?&]v=\d/.test(location.href);
  // the reaction's type is only in its little icon (an SVG with no name) - told apart by its colours (live test 2026-11-25:
  // Like = #0866FF #02ADFC #2B7EFF; Haha = yellow #FFF287 with the brown #4B280E); the others by their look until seen
  function reactionType(row) {
    const img = row && row.querySelector('img[src^="data:image/svg"]');
    if (!img) return "";
    let svg = ""; try { svg = decodeURIComponent(img.src.slice(img.src.indexOf(",") + 1)); } catch (e) { return ""; }
    const c = new Set((svg.match(/#[0-9A-Fa-f]{6}\b/g) || []).map(x => x.toUpperCase()));
    const hue = h => { const r = parseInt(h.slice(1, 3), 16) / 255, g = parseInt(h.slice(3, 5), 16) / 255, b = parseInt(h.slice(5, 7), 16) / 255;
      const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn; if (d < 0.15) return -1;
      let x = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; return (x * 60 + 360) % 360; };
    const hs = [...c].map(hue).filter(x => x >= 0);
    const has = (lo, hi) => hs.some(x => x >= lo && x <= hi);
    const yellow = has(45, 65), blue = has(195, 230), red = has(340, 360) || has(0, 8), dark = [...c].some(h => parseInt(h.slice(1, 3), 16) < 0x40 && parseInt(h.slice(3, 5), 16) < 0x40);
    if (c.has("#0866FF") || (blue && !yellow && !red)) return "Like";
    // Haha = the yellow face with the pink tongue (#FF60A4); a yellow face with no tongue, tear or heart = Wow (live test:
    // #4B280E #1C1C1D #E0761A #FF5758 #FFF287 #F68628)
    if (yellow && c.has("#FF60A4")) return "Haha";
    if (!yellow && red && !dark) return "Love";
    if (!yellow && (has(8, 40) || red) && dark) return "Angry";
    if (yellow && blue) return "Sad";
    if (yellow && (c.has("#FA2E3E") || c.has("#BC0A26"))) return "Care";      // the heart's reds (Haha has them too, so it goes first)
    if (yellow) return "Wow";
    return "";
  }

  let seen = new Set(), primed = "", queue = [], typing = false, lastSeen = 0, alertsAt = 0, settleUntil = 0, openedAt = 0;

  function keyOf(a, user, text) {
    const idEl = a.id ? a : a.querySelector("[id]");
    // React's own ids ("_r_nt_", ":r12:") change when the list redraws - only a lasting id counts
    const id = idEl && idEl.id && !/^(client:|_r_|:r)/.test(idEl.id) ? idEl.id : "";
    return id || user + "|" + text.slice(0, 80);
  }

  // one comment: {user, text} - the first link is the commenter, then the words that aren't Facebook's buttons
  function parse(a) {
    const label = a.getAttribute("aria-label") || "";
    if (label && !/comment|reply|star/i.test(label)) return null;   // the video's own post, not a comment
    const by = label.match(BY);
    const link = a.querySelector('a[role="link"] span[dir="auto"], a[role="link"]');
    const user = (by ? by[1] : txt(link)).slice(0, 60);
    if (!user) return null;
    const parts = [];
    for (const el of a.querySelectorAll('div[dir="auto"], span[dir="auto"]')) {
      if (el.closest('a') || el.querySelector('div[dir="auto"], span[dir="auto"]')) continue;
      const t = txt(el);
      if (t && t !== user && !UI.test(t) && !parts.includes(t)) parts.push(t);
    }
    // Stars: a piece of its own that says "100 sent" (or "sent 100 Stars"), next to the words
    const STARS = /^(?:(\d[\d,.]*)\s+(?:Stars?\s+)?sent|sent\s+(\d[\d,.]*)\s+Stars?)$/i;
    const starPart = parts.find(t => STARS.test(t));
    let text = parts.filter(t => t !== starPart).join(" ").trim();
    const all = txt(a);
    const base = { user };
    if (starPart) {
      const m = starPart.match(STARS);
      return { ...base, kind: "stars", count: (m[1] || m[2]).replace(/[^\d]/g, ""), text, all };
    }
    if (!text) return null;
    // follows and shares come from the Alerts panel only (19:15 live test: Facebook's chatbot answering !followage -
    // "Followed BatteryRequired for 1,308 days!" - was taken for a follow)
    return { ...base, kind: "chat", text: text.slice(0, 300), all };
  }

  function scan() {
    if (!onLivePage()) return;
    const page = location.pathname + location.search;
    // a page just opened: what's there already is old. Facebook fills the comment list a moment after the page opens
    // (live test 19:20: each refresh sent the whole history again) - so everything up to 4 s after the first comments
    // show up counts as old too
    if (primed !== page) { primed = page; settleUntil = 0; openedAt = Date.now(); }
    const arts = document.querySelectorAll('[role="article"]');
    if (!settleUntil && arts.length) settleUntil = Date.now() + 4000;
    else if (!settleUntil && Date.now() - openedAt > 8000) settleUntil = Date.now();    // no comments yet: the next one is new
    const fresh = !settleUntil || Date.now() < settleUntil;
    for (const a of arts) {
      const e = parse(a);
      if (!e) continue;
      const id = keyOf(a, e.user, e.text || e.kind);
      if (seen.has(id)) continue;
      seen.add(id);
      lastSeen = Date.now();
      if (fresh) continue;
      delete e.all;
      queue.push({ ...e, id });
    }
    // Live Producer's Alerts panel: "NAME shared your stream", "NAME followed you", "NAME sent 100 Stars"
    const AL = /^(.+?) (shared your (?:stream|live video|video)|reacted to your (?:stream|live video|video)|(?:followed|started following|is now following) you|sent (\d[\d,.]*) Stars?)$/i;
    // light: spans only, a cheap textContent length check before anything else, at most every 3 s (19:13 live test: the
    // first version read the visible text of every element on each change and stalled the extension)
    const doAlerts = fresh || Date.now() - alertsAt > 3000;
    if (doAlerts) alertsAt = Date.now();
    for (const el of doAlerts ? document.querySelectorAll("span") : []) {
      const raw = el.textContent || "";
      if (raw.length > 160 || raw.length < 8 || !AL.test(raw.replace(/\s+/g, " ").trim())) continue;
      if ([...el.children].some(c => AL.test((c.textContent || "").replace(/\s+/g, " ").trim()))) continue;   // the innermost only
      if (el.closest('[role="article"]')) continue;
      const t = raw.replace(/\s+/g, " ").trim();
      const m = t.match(AL);
      const id = "alert|" + t;
      if (seen.has(id)) continue;
      seen.add(id);
      lastSeen = Date.now();
      if (fresh) continue;
      const kind = /^shared/i.test(m[2]) ? "share" : /^sent/i.test(m[2]) ? "stars" : /^reacted/i.test(m[2]) ? "reaction" : "follow";
      let row = el;
      for (let i = 0; i < 5 && row.parentElement && !row.querySelector("img"); i++) row = row.parentElement;
      queue.push({ id, user: m[1].slice(0, 60), kind, ...(kind === "stars" ? { count: m[3].replace(/[^\d]/g, ""), text: "" } : {}),
                   ...(kind === "reaction" ? { reaction: reactionType(row) } : {}) });
    }
    if (seen.size > 3000) seen = new Set([...seen].slice(-1500));
  }

  function viewers() {
    for (const el of document.querySelectorAll('[aria-label]')) {
      const m = (el.getAttribute("aria-label") || "").match(/([\d.,]+\s*[KkMm]?)\s+(?:viewers?|watching|people watching)/i);
      if (m) return m[1].replace(/\s/g, "");
    }
    const m = txt(document.body).match(/\b([\d.,]+\s*[KkMm]?)\s+(?:watching now|watching|viewers)\b/i);
    return m ? m[1].replace(/\s/g, "") : null;
  }

  // the comment box: a text box that says "comment" (Facebook: "Write a comment...", "Comment as ...")
  function box() {
    const boxes = [...document.querySelectorAll('[role="textbox"][contenteditable="true"]')];
    return boxes.find(b => /comment/i.test(b.getAttribute("aria-label") || "") || /comment/i.test(b.getAttribute("aria-placeholder") || ""))
      || boxes.find(b => b.closest('[role="complementary"], [role="dialog"], form')) || null;
  }

  function signedIn() {
    if (box()) return true;
    return !document.querySelector('form[action*="login"], a[href*="/login/"]');
  }

  async function type(text) {
    const b = box();
    if (!b) return;
    b.focus();
    document.execCommand("selectAll", false);
    document.execCommand("insertText", false, text);
    await sleep(400);
    for (const t of ["keydown", "keypress", "keyup"])
      b.dispatchEvent(new KeyboardEvent(t, { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true }));
    await sleep(1500);
  }

  async function tick() {
    try {
      scan();
      if (onLivePage()) {
        const events = queue.splice(0, 200);
        const j = await chrome.runtime.sendMessage({ type: "push", site: "facebook", body: {
          page: { url: location.origin + location.pathname, title: document.title, producer: /\/live\/producer\//.test(location.href),
                  signed_in: signedIn(), viewers: viewers(), comments_seen: lastSeen ? Math.round((Date.now() - lastSeen) / 1000) : null },
          events } });
        if (j && Array.isArray(j.send) && j.send.length && !typing) {
          typing = true;
          for (const line of j.send) await type(String(line).slice(0, 500));
          typing = false;
        }
      }
    } catch (e) { typing = false; }                            // the extension was reloaded, or Castwell Toolkit is off
    setTimeout(tick, 1500);
  }

  new MutationObserver(() => { clearTimeout(scan.t); scan.t = setTimeout(scan, 250); })
    .observe(document.documentElement, { childList: true, subtree: true });
  tick();
})();
