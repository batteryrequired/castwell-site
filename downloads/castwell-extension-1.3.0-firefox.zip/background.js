// Castwell Toolkit for TikTok & Facebook LIVE - the go-between: the TikTok page (content.js) and the Facebook page (facebook.js)
// can't reach Castwell Toolkit on this PC themselves, so they hand what they read to this service worker, which posts it to
// Castwell Toolkit and hands back the replies to type.
const DEFAULT = "http://127.0.0.1:8800";

chrome.runtime.onMessage.addListener((m, sender, reply) => {
  if (!m || m.type !== "push") return;
  (async () => {
    const { address = DEFAULT, code = "" } = await chrome.storage.local.get(["address", "code"]);
    const base = String(address || DEFAULT).trim().replace(/\/+$/, "");
    let last;
    try {
      const site = m.site === "facebook" ? "facebook" : "tiktok";
      const r = await fetch(base + "/api/" + site + "/push", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...m.body, key: code, v: chrome.runtime.getManifest().version }),
      });
      const j = await r.json();
      const nm = site === "facebook" ? "Facebook" : "TikTok";
      if (r.status === 404 && site === "facebook") j.error = "update Castwell Toolkit - this version has no Facebook yet";
      last = { ok: r.ok && j.watching && j.signed_in, site: nm, note: j.error || j.note ||
        (j.signed_in ? `Reading your ${nm} live chat` : `Castwell Toolkit sees the page - sign in to ${nm} in this browser`) };
      reply(j);
      const all = (await chrome.storage.local.get("sites")).sites || {};
      all[site] = { ...last, t: Date.now() };
      await chrome.storage.local.set({ sites: all });
    } catch (e) {
      last = { ok: false, note: "Castwell Toolkit isn't running at " + base + " (start Castwell Toolkit)" };
      reply({ error: String(e), send: [] });
    }
    await chrome.storage.local.set({ last: { ...last, t: Date.now() } });
  })();
  return true;       // the reply comes later
});
