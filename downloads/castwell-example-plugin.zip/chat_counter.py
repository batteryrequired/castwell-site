"""Chat counter: counts how many messages each viewer sends this stream, answers !mycount in chat, and adds a
"Chat counter" tab with the top chatters. An example plugin for Castwell Toolkit - copy it and change it."""

INFO = {"id": "chat_counter", "name": "Chat counter", "order": 100, "version": "1.0",
        "author": "batteryrequired", "description": "Counts chat messages per viewer this stream; !mycount answers in chat."}
TAB = {"label": "Chat counter", "section": "Plugins", "page": "index.html"}   # its page: chat_counter/web/index.html

_app = None
counts: dict = {}           # login -> {"user": name, "n": messages, "platform": where}


def on_chat(d: dict) -> None:
    login = str(d.get("login") or "").lower()
    if not login or d.get("broadcaster"):
        return
    c = counts.setdefault(login, {"user": d.get("user") or login, "n": 0, "platform": d.get("platform") or "twitch"})
    c["n"] += 1
    if str(d.get("text") or "").strip().lower() == "!mycount":
        plat = _app.module(d.get("platform") or "twitch")      # twitch / youtube / kick / tiktok - each has say(text)
        if plat and hasattr(plat, "say"):
            plat.say(f"@{c['user']} you've sent {c['n']} messages this stream!")


def on_stream(d: dict) -> None:
    if d.get("online"):
        counts.clear()                                       # a new stream: start counting again
        _app.log("chat counter: new stream, counts reset")


def setup(app) -> None:
    global _app
    _app = app
    app.bus.on("chat", on_chat)
    app.bus.on("stream", on_stream)


def status():                                                # optional: a light on the Home tab
    return {"ok": True, "label": f"{len(counts)} chatters", "detail": f"{sum(c['n'] for c in counts.values())} messages"}


def r_top(app, query, body):
    top = sorted(counts.values(), key=lambda c: -c["n"])[:int(query.get("n") or 20)]
    return 200, {"top": top}


def r_reset(app, query, body):
    counts.clear()
    return 200, {"ok": True}


ROUTES = {("GET", "/api/chat_counter"): r_top, ("POST", "/api/chat_counter/reset"): r_reset}
