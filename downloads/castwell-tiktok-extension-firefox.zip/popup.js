const $ = id => document.getElementById(id);
// the status line: a bold word and a note (built with text nodes - nothing is parsed as HTML)
function status(word, cls, note) {
  const st = $("st"), b = document.createElement("b");
  b.textContent = word;
  if (cls) b.className = cls;
  st.replaceChildren(b, document.createTextNode(note ? " - " + note : ""));
}
async function paint() {
  const { address = "http://127.0.0.1:8800", code = "", last } = await chrome.storage.local.get(["address", "code", "last"]);
  if (document.activeElement !== $("code")) $("code").value = code;
  if (document.activeElement !== $("address")) $("address").value = address;
  const age = last ? Math.round((Date.now() - last.t) / 1000) : null;
  if (!last || age > 30) status("Waiting", "", "open your TikTok LIVE page in this browser.");
  else status(last.ok ? "Connected" : "Not yet", last.ok ? "ok" : "bad", String(last.note || ""));
}
$("save").onclick = async () => {
  await chrome.storage.local.set({ code: $("code").value.trim().toUpperCase(), address: $("address").value.trim() || "http://127.0.0.1:8800" });
  status("Saved.", "", "");
  setTimeout(paint, 2500);
};
paint(); setInterval(paint, 2000);
