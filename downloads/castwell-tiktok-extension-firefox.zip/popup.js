const $ = id => document.getElementById(id);
async function paint() {
  const { address = "http://127.0.0.1:8800", code = "", last } = await chrome.storage.local.get(["address", "code", "last"]);
  if (document.activeElement !== $("code")) $("code").value = code;
  if (document.activeElement !== $("address")) $("address").value = address;
  const age = last ? Math.round((Date.now() - last.t) / 1000) : null;
  $("st").innerHTML = !last || age > 30 ? "<b>Waiting</b> - open your TikTok LIVE page in this browser."
    : `<b class="${last.ok ? "ok" : "bad"}">${last.ok ? "Connected" : "Not yet"}</b> - ${last.note.replace(/[<>&]/g, "")}`;
}
$("save").onclick = async () => {
  await chrome.storage.local.set({ code: $("code").value.trim().toUpperCase(), address: $("address").value.trim() || "http://127.0.0.1:8800" });
  $("st").innerHTML = "<b>Saved.</b>";
  setTimeout(paint, 2500);
};
paint(); setInterval(paint, 2000);
