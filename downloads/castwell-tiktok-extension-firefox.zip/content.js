// Castwell for TikTok LIVE - runs on tiktok.com. On a LIVE page (tiktok.com/@name/live) it reads new chat lines,
// gifts and follows plus the viewer count, sends them to Castwell every 1.5 s (through background.js), and types the
// replies Castwell sends back into the chat box - as the TikTok account signed in in this browser.
(() => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const txt = el => ((el && el.innerText) || "").replace(/\s+/g, " ").trim();
  const pageUser = () => (location.pathname.match(/^\/@([^/]+)\/live/) || [])[1] || "";

  let queue = [], seen = new Set(), primed = "", lastChat = 0, typing = false;

  // TikTok only shows LIVE chat to signed-in visitors; signed out, the top bar has a "Log in" button
  function signedIn() {
    if (Date.now() - lastChat < 120000) return true;
    if (document.querySelector('[data-e2e="top-login-button"], [data-e2e="nav-login-button"], #header-login-button')) return false;
    return ![...document.querySelectorAll("header button, header a, button")].some(b => /^log in$/i.test(txt(b)));
  }

  function viewers() {
    const m = txt(document.querySelector('[data-e2e="live-chat-container"]')).match(/Viewers\W{0,4}([\d.,]+\s*[KkMm]?)\b/);
    return m ? m[1].replace(/\s/g, "") : null;
  }

  // the words (and emote names) after the viewer's name in one chat row
  function afterName(row, owner, noAlt) {
    let out = "", past = false;
    const w = document.createTreeWalker(row, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
    for (let n = w.nextNode(); n; n = w.nextNode()) {
      if (!past) { if (n === owner) past = true; continue; }
      if (owner.contains(n)) continue;
      if (n.nodeType === 3) out += n.nodeValue;
      else if (!noAlt && n.tagName === "IMG" && n.alt) out += " " + n.alt + " ";
    }
    return out.replace(/\s+/g, " ").replace(/^[:：]\s*/, "").trim();
  }

  function parse(row) {
    const owner = row.querySelector('[data-e2e="message-owner-name"]');
    if (!owner) return null;                                   // TikTok's own notices
    const user = txt(owner);
    if (!user) return null;
    const rest = afterName(row, owner);
    const host = txt(document.querySelector('[data-e2e="room-header-anchor-name"]'));
    const base = { user, id: (row.dataset.index || "") + "|" + user + "|" + rest.slice(0, 60) };
    if (/^joined\b/i.test(rest)) return { ...base, kind: "join" };
    if (/liked the LIVE/i.test(rest)) return { ...base, kind: "like" };
    if (/^shared the LIVE/i.test(rest)) return { ...base, kind: "share" };
    if (/^followed\b|^is following\b/i.test(rest)) return { ...base, kind: "follow" };
    if (/^sent\b/i.test(rest)) {
      const count = (rest.match(/[x×]\s*(\d[\d,]*)/i) || [])[1] || "1";
      let gift = afterName(row, owner, true).replace(/^sent\s*/i, "").replace(/[x×]\s*\d[\d,]*.*$/i, "").trim();
      if (!gift) gift = [...row.querySelectorAll("img")].map(i => i.alt).filter(Boolean).pop() || "a gift";
      return { ...base, kind: "gift", gift, count };
    }
    if (!rest) return null;
    return { ...base, kind: "chat", text: rest, host: !!host && host === user,
             mod: [...row.querySelectorAll("img")].some(i => /moderator/i.test(i.alt || "")) };
  }

  function scan() {
    const user = pageUser();
    const box = document.querySelector('[data-e2e="live-chat-container"]');
    if (!user || !box) return;
    const rows = [...box.querySelectorAll("[data-index]")];
    const fresh = primed !== user;                             // a page just opened: what's there already is old
    for (const row of rows) {
      const e = parse(row);
      if (!e || seen.has(e.id)) continue;
      seen.add(e.id);
      if (fresh) continue;
      if (e.kind === "chat") lastChat = Date.now();
      queue.push(e);
    }
    primed = user;
    if (seen.size > 2000) seen = new Set([...seen].slice(-1000));
  }

  async function type(text) {
    const box = document.querySelector('[data-e2e="room-chat-input-field"]');
    if (!box) return;
    box.focus();
    document.execCommand("selectAll", false);
    document.execCommand("insertText", false, text);
    box.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
    await sleep(400);
    const send = document.querySelector('[data-e2e="room-chat-send-btn"]');
    if (send && !/not-allowed|invisible/.test(send.className)) send.click();
    else box.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }));
    await sleep(1500);
  }

  async function tick() {
    try {
      scan();
      const user = pageUser();
      if (user) {
        const events = queue.splice(0, 200);
        const j = await chrome.runtime.sendMessage({ type: "push", body: {
          page: { user, signed_in: signedIn(), viewers: viewers() }, events } });
        if (j && Array.isArray(j.send) && j.send.length && !typing) {
          typing = true;
          for (const line of j.send) await type(String(line).slice(0, 150));
          typing = false;
        }
      }
    } catch (e) { typing = false; }                            // the extension was reloaded, or Castwell is off
    setTimeout(tick, 1500);
  }

  new MutationObserver(() => { clearTimeout(scan.t); scan.t = setTimeout(scan, 250); })
    .observe(document.documentElement, { childList: true, subtree: true });
  tick();
})();
