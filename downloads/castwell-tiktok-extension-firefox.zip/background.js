// Castwell for TikTok LIVE - the go-between: the TikTok page (content.js) can't reach Castwell on this PC itself, so
// it hands what it read to this service worker, which posts it to Castwell and hands back the replies to type.
const DEFAULT = "http://127.0.0.1:8800";

chrome.runtime.onMessage.addListener((m, sender, reply) => {
  if (!m || m.type !== "push") return;
  (async () => {
    const { address = DEFAULT, code = "" } = await chrome.storage.local.get(["address", "code"]);
    const base = String(address || DEFAULT).trim().replace(/\/+$/, "");
    let last;
    try {
      const r = await fetch(base + "/api/tiktok/push", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...m.body, key: code }),
      });
      const j = await r.json();
      last = { ok: r.ok && j.watching && j.signed_in, note: j.error || j.note ||
        (j.signed_in ? "Reading your TikTok LIVE chat" : "Castwell sees the page - sign in to TikTok in this browser") };
      reply(j);
    } catch (e) {
      last = { ok: false, note: "Castwell isn't running at " + base + " (start Castwell)" };
      reply({ error: String(e), send: [] });
    }
    await chrome.storage.local.set({ last: { ...last, t: Date.now() } });
  })();
  return true;       // the reply comes later
});
